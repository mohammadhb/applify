![Logo](https://raw.githubusercontent.com/mohammadhb/applify/main/assets/img/logo.svg)

# Applify
## A chrome extenion that helps you with applying
